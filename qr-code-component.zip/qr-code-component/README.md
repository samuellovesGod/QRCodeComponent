# QR code component

A Pen created on CodePen.

Original URL: [https://codepen.io/Sam-Ihonre/pen/dPpyebp](https://codepen.io/Sam-Ihonre/pen/dPpyebp).

